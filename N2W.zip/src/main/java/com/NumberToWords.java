package com;

public class NumberToWords {

	public static void main(String[] args) {
		if (args.length == 0 || args.length > 1) {
			System.out.println("No arguments or > 1 argements passed");
			return;
		}
		int number;
		try {
			number = Integer.parseInt(args[0]);
			System.out.println(new NumberToWords().numberToWords(number)); // 1000000000
		} catch (NumberFormatException e) {
			if (args[0].length() > 9)
				System.out.println(NumberName.UnsupportedNumber.name());
			else
				System.out.println("Invalid argument, it should be nubmer");
			return;
		}

	}

	public String numberToWords(int num) {
		if (num > 999999999)
			return NumberName.UnsupportedNumber.name();
		StringBuilder sb = new StringBuilder();

		if (num == 0) {
			return NumberName.getName(0).name();
		}

		if (num >= 1000000000) {
			num = getNum(sb, num, 1000000000, NumberName.Billion.name());
		}

		if (num >= 1000000) {
			num = getNum(sb, num, 1000000, NumberName.Million.name());
		}

		if (num >= 1000) {
			num = getNum(sb, num, 1000, NumberName.Thousand.name());
		}

		if (num > 0) {
			sb.append(convert(num));
		}

		return sb.toString().trim();
	}

	private int getNum(StringBuilder sb, int num, int divisor, String name) {
		appendText(sb, convert(getQuotient(num, divisor)) + " " + name);
		return getReminder(num, divisor);
	}

	private void appendText(StringBuilder sb, String text) {
		sb.append(text);
	}

	private int getReminder(int num, int divisor) {
		return num % divisor;
	}

	private int getQuotient(int num, int divisor) {
		return num / divisor;
	}

	private String convert(int num) {

		StringBuilder sb = new StringBuilder();

		if (num >= 100) {
			appendText(sb, " "
					+ NumberName.getName(getQuotient(num, 100)).name() + " "
					+ NumberName.Hundred.name());
			num = getReminder(num, 100);
		}

		if (num > 0) {
			if (num > 0 && num <= 20) {
				appendText(sb, " " + NumberName.getName(num).name());
			} else {
				appendText(sb,
						" "
								+ NumberName.getName(getQuotient(num, 10) * 10)
										.name());

				if (getReminder(num, 10) > 0) {
					appendText(sb,
							" "
									+ NumberName.getName(getReminder(num, 10))
											.name());
				}
			}
		}

		return sb.toString();
	}

	

}
