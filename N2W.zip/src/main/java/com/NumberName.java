package com;

import java.io.Serializable;

public enum NumberName implements Serializable {
	Zero, One, Two, Three, Four, Five, Six, Seven, Eight, Nine, Ten, Eleven, Twelve, Thirteen, Fourteen, Fifteen, Sixteen, Seventeen, Eighteen, Nineteen, Twenty, Thirty, Forty, Fifty, Sixty, Seventy, Eighty, Ninety, Hundred, Billion, Million, Thousand, Unknown, UnsupportedNumber;
	static NumberName getName(int number) {
		switch (number) {
		case 0:
			return NumberName.Zero;
		case 1:
			return NumberName.One;
		case 2:
			return NumberName.Two;
		case 3:
			return NumberName.Three;
		case 4:
			return NumberName.Four;
		case 5:
			return NumberName.Five;
		case 6:
			return NumberName.Six;
		case 7:
			return NumberName.Seven;
		case 8:
			return NumberName.Eight;
		case 9:
			return NumberName.Nine;
		case 10:
			return NumberName.Ten;
		case 11:
			return NumberName.Eleven;
		case 12:
			return NumberName.Twelve;
		case 13:
			return NumberName.Thirteen;
		case 14:
			return NumberName.Fourteen;
		case 15:
			return NumberName.Fifteen;
		case 16:
			return NumberName.Sixteen;
		case 17:
			return NumberName.Seventeen;
		case 18:
			return NumberName.Eighteen;
		case 19:
			return NumberName.Nineteen;
		case 20:
			return NumberName.Twenty;
		case 30:
			return NumberName.Thirty;
		case 40:
			return NumberName.Forty;
		case 50:
			return NumberName.Fifty;
		case 60:
			return NumberName.Sixty;
		case 70:
			return NumberName.Seventy;
		case 80:
			return NumberName.Eighty;
		case 90:
			return NumberName.Ninety;
		default:
			return NumberName.Unknown;
		}

	}

}
